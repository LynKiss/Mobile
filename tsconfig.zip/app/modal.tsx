import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
} from "react-native";
import AntDesign from "@expo/vector-icons/AntDesign";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import { NavigationProp, useNavigation } from "@react-navigation/native";
import { RootStackParamList } from "../types/route";

const { width } = Dimensions.get("window");

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    width: width * 0.9,
    maxHeight: "80%",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
    paddingBottom: 15,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  closeButton: {
    padding: 5,
  },
  productImage: {
    width: "100%",
    height: 200,
    borderRadius: 12,
    marginBottom: 20,
  },
  productTitle: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
    textAlign: "center",
  },
  productPrice: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#007AFF",
    textAlign: "center",
    marginBottom: 15,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  ratingText: {
    marginLeft: 10,
    fontSize: 16,
    color: "#666",
    fontWeight: "600",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
    marginTop: 15,
  },
  description: {
    fontSize: 14,
    color: "#666",
    lineHeight: 20,
    textAlign: "justify",
    marginBottom: 15,
  },
  featureList: {
    marginBottom: 15,
  },
  featureItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  featureText: {
    fontSize: 14,
    color: "#333",
    marginLeft: 10,
  },
  actionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
    gap: 10,
  },
  addToCartButton: {
    backgroundColor: "#28a745",
    padding: 15,
    borderRadius: 10,
    flex: 1,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  closeModalButton: {
    backgroundColor: "#6c757d",
    padding: 15,
    borderRadius: 10,
    flex: 1,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
  specsContainer: {
    backgroundColor: "#f8f9fa",
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
  },
  specItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#e9ecef",
  },
  specLabel: {
    fontSize: 14,
    color: "#666",
    fontWeight: "600",
  },
  specValue: {
    fontSize: 14,
    color: "#333",
    fontWeight: "600",
  },
});

interface IProduct {
  id: number;
  title: string;
  price: number;
  rating: number;
  image: any;
  description: string;
  category: string;
}

interface IProps {
  modalVisible: boolean;
  setModalVisible: (visible: boolean) => void;
  product?: IProduct | null;
}

const ProductDetailModal = (props: IProps) => {
  const { modalVisible, setModalVisible, product } = props;
  const navigation: NavigationProp<RootStackParamList> = useNavigation();

  // Mock product details based on ID (similar to detail.tsx)
  const productDetails = {
    1: {
      description:
        "iPhone 15 Pro Max với thiết kế titan cao cấp, chip A17 Pro mạnh mẽ, camera 48MP và tính năng quay video chuyên nghiệp.",
      features: [
        "Chip A17 Pro với 6 nhân CPU",
        "Camera chính 48MP với sensor lớn",
        "Quay video ProRes 4K",
        "Kết nối USB-C tốc độ cao",
        "Titanium frame bền bỉ",
      ],
      specs: {
        "Màn hình": "6.7 inch Super Retina XDR",
        Chip: "A17 Pro",
        RAM: "8GB",
        "Bộ nhớ": "256GB/512GB/1TB",
        Camera: "48MP + 12MP + 12MP",
        Pin: "4422 mAh",
      },
    },
    2: {
      description:
        "Samsung Galaxy S24 Ultra với bút S-Pen tích hợp, camera 200MP đột phá, màn hình Dynamic AMOLED 2X 6.8 inch.",
      features: [
        "Bút S-Pen tích hợp",
        "Camera chính 200MP",
        "Màn hình 6.8 inch 120Hz",
        "Chip Snapdragon 8 Gen 3",
        "Chống nước IP68",
      ],
      specs: {
        "Màn hình": "6.8 inch Dynamic AMOLED 2X",
        Chip: "Snapdragon 8 Gen 3",
        RAM: "12GB",
        "Bộ nhớ": "256GB/512GB/1TB",
        Camera: "200MP + 50MP + 12MP + 10MP",
        Pin: "5000 mAh",
      },
    },
    3: {
      description:
        "MacBook Pro M3 với chip Apple M3 mạnh mẽ, màn hình Liquid Retina XDR 14.2 inch, thời lượng pin lên đến 18 giờ.",
      features: [
        "Chip Apple M3 8-core",
        "Màn hình Liquid Retina XDR",
        "Thời lượng pin 18 giờ",
        "Thiết kế Unibody aluminum",
        "6 loa và 3 micro",
      ],
      specs: {
        "Màn hình": "14.2 inch Liquid Retina XDR",
        Chip: "Apple M3",
        RAM: "8GB/16GB",
        SSD: "512GB/1TB/2TB",
        Cổng: "Thunderbolt 4, HDMI, SDXC",
        Pin: "70Wh",
      },
    },
  };

  const details = product
    ? productDetails[product.id as keyof typeof productDetails]
    : null;

  const formatPrice = (price: number) => {
    return price.toLocaleString("vi-VN") + "₫";
  };

  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FontAwesome
          key={i}
          name={i <= rating ? "star" : "star-o"}
          size={20}
          color={i <= rating ? "#FFD700" : "#ccc"}
        />
      );
    }
    return stars;
  };

  const handleAddToCart = () => {
    // Navigate to cart screen
    navigation.navigate("Cart");
    setModalVisible(false);
  };

  const handleViewFullDetails = () => {
    if (product) {
      navigation.navigate("Detail", {
        id: product.id,
        title: product.title,
        start: product.rating,
      });
      setModalVisible(false);
    }
  };

  if (!product) return null;

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => setModalVisible(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.container}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Chi Tiết Sản Phẩm</Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setModalVisible(false)}
            >
              <AntDesign name="close" size={24} color="#666" />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Product Image */}
            <Image
              source={product.image}
              style={styles.productImage}
              resizeMode="cover"
            />

            {/* Product Title */}
            <Text style={styles.productTitle}>{product.title}</Text>

            {/* Product Price */}
            <Text style={styles.productPrice}>
              {formatPrice(product.price)}
            </Text>

            {/* Rating */}
            <View style={styles.ratingContainer}>
              {renderStars(product.rating)}
              <Text style={styles.ratingText}>{product.rating}/5</Text>
            </View>

            {/* Description */}
            <Text style={styles.sectionTitle}>Mô Tả Sản Phẩm</Text>
            <Text style={styles.description}>
              {details?.description || product.description}
            </Text>

            {/* Features */}
            {details?.features && details.features.length > 0 && (
              <>
                <Text style={styles.sectionTitle}>Tính Năng Nổi Bật</Text>
                <View style={styles.featureList}>
                  {details.features.map((feature, index) => (
                    <View key={index} style={styles.featureItem}>
                      <AntDesign name="checkcircle" size={16} color="#28a745" />
                      <Text style={styles.featureText}>{feature}</Text>
                    </View>
                  ))}
                </View>
              </>
            )}

            {/* Specifications */}
            {details?.specs && Object.keys(details.specs).length > 0 && (
              <>
                <Text style={styles.sectionTitle}>Thông Số Kỹ Thuật</Text>
                <View style={styles.specsContainer}>
                  {Object.entries(details.specs).map(([key, value], index) => (
                    <View key={index} style={styles.specItem}>
                      <Text style={styles.specLabel}>{key}</Text>
                      <Text style={styles.specValue}>{value}</Text>
                    </View>
                  ))}
                </View>
              </>
            )}
          </ScrollView>

          {/* Action Buttons */}
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={styles.closeModalButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.buttonText}>Đóng</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.addToCartButton}
              onPress={handleAddToCart}
            >
              <Text style={styles.buttonText}>Thêm Vào Giỏ</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default ProductDetailModal;
