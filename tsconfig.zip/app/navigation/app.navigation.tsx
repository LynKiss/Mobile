import { createDrawerNavigator } from "@react-navigation/drawer";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import HomeScreen from "../home";
import HomeNewScreen from "../home-new";
import AboutScreen from "../about";
import DetailScreen from "../detail";
import LoginScreen from "../login";
import RegisterScreen from "../register";
import CartScreen from "../cart";
import CheckoutScreen from "../checkout";
import AppHeader from "./app.header";
import { RootStackParamList } from "../../types/route";

// Stack Navigator cho màn hình Home chính
const HomeStack = () => {
  const Stack = createNativeStackNavigator<RootStackParamList>();
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
};

// Stack Navigator cho các màn hình sản phẩm (Detail, Cart, Checkout)
const ProductsStack = () => {
  const Stack = createNativeStackNavigator<RootStackParamList>();
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Detail"
        component={DetailScreen}
        options={{ title: "Chi tiết", headerShown: false }}
      />
      <Stack.Screen
        name="Cart"
        component={CartScreen}
        options={{ title: "Giỏ hàng", headerShown: false }}
      />
      <Stack.Screen
        name="Checkout"
        component={CheckoutScreen}
        options={{ title: "Thanh toán", headerShown: false }}
      />
    </Stack.Navigator>
  );
};

// Stack Navigator cho authentication và trang chủ mới
const AuthHomeStack = () => {
  const Stack = createNativeStackNavigator<RootStackParamList>();
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Login"
        component={LoginScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Register"
        component={RegisterScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="HomeNew"
        component={HomeNewScreen}
        options={{ header: () => <AppHeader /> }}
      />
    </Stack.Navigator>
  );
};

const AppNavigation = () => {
  const Drawer = createDrawerNavigator();
  return (
    <Drawer.Navigator>
      <Drawer.Screen
        name="AuthHome"
        component={AuthHomeStack}
        options={{ title: "Trang chủ", header: () => <></> }}
      />
      <Drawer.Screen
        name="Home"
        component={HomeStack}
        options={{ title: "Sản phẩm", header: () => <AppHeader /> }}
      />

      <Drawer.Screen
        name="About"
        component={AboutScreen}
        options={{ title: "Giới thiệu", header: () => <AppHeader /> }}
      />
      <Drawer.Screen
        name="Cart"
        component={CartScreen}
        options={{ title: "Giỏ hàng", header: () => <AppHeader /> }}
      />
      <Drawer.Screen
        name="Checkout"
        component={CheckoutScreen}
        options={{ title: "Thanh toán", header: () => <AppHeader /> }}
      />
    </Drawer.Navigator>
  );
};

export default AppNavigation;
