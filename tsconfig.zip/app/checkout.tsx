import React, { useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
} from "react-native";
import { NavigationProp, useNavigation } from "@react-navigation/native";
import { RootStackParamList } from "../types/route";

const CheckoutScreen = () => {
  const navigation = useNavigation<NavigationProp<RootStackParamList>>();
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    paymentMethod: "cod", // cod: thanh toán khi nhận hàng
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleCheckout = () => {
    // Kiểm tra thông tin bắt buộc
    if (!formData.fullName || !formData.phone || !formData.address) {
      Alert.alert("Lỗi", "Vui lòng điền đầy đủ thông tin bắt buộc");
      return;
    }

    // Mô phỏng quá trình thanh toán
    Alert.alert(
      "Thành công",
      "Đơn hàng của bạn đã được đặt thành công!\nChúng tôi sẽ liên hệ với bạn sớm nhất.",
      [
        {
          text: "OK",
          onPress: () => navigation.navigate("Home"),
        },
      ]
    );
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString("vi-VN") + "₫";
  };

  // Giả sử tổng tiền là 500,000đ
  const totalAmount = 500000;
  const shippingFee = 30000;
  const finalAmount = totalAmount + shippingFee;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Thanh Toán</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Thông tin giao hàng</Text>

        <TextInput
          style={styles.input}
          placeholder="Họ và tên *"
          value={formData.fullName}
          onChangeText={(text) => handleInputChange("fullName", text)}
        />

        <TextInput
          style={styles.input}
          placeholder="Email"
          value={formData.email}
          onChangeText={(text) => handleInputChange("email", text)}
          keyboardType="email-address"
        />

        <TextInput
          style={styles.input}
          placeholder="Số điện thoại *"
          value={formData.phone}
          onChangeText={(text) => handleInputChange("phone", text)}
          keyboardType="phone-pad"
        />

        <TextInput
          style={styles.input}
          placeholder="Địa chỉ *"
          value={formData.address}
          onChangeText={(text) => handleInputChange("address", text)}
        />

        <TextInput
          style={styles.input}
          placeholder="Thành phố"
          value={formData.city}
          onChangeText={(text) => handleInputChange("city", text)}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Phương thức thanh toán</Text>

        <TouchableOpacity
          style={[
            styles.paymentOption,
            formData.paymentMethod === "cod" && styles.paymentOptionSelected,
          ]}
          onPress={() => handleInputChange("paymentMethod", "cod")}
        >
          <View style={styles.radioContainer}>
            <View
              style={[
                styles.radio,
                formData.paymentMethod === "cod" && styles.radioSelected,
              ]}
            />
          </View>
          <Text style={styles.paymentText}>Thanh toán khi nhận hàng (COD)</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.paymentOption,
            formData.paymentMethod === "bank" && styles.paymentOptionSelected,
          ]}
          onPress={() => handleInputChange("paymentMethod", "bank")}
        >
          <View style={styles.radioContainer}>
            <View
              style={[
                styles.radio,
                formData.paymentMethod === "bank" && styles.radioSelected,
              ]}
            />
          </View>
          <Text style={styles.paymentText}>Chuyển khoản ngân hàng</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Tổng thanh toán</Text>

        <View style={styles.priceRow}>
          <Text style={styles.priceLabel}>Tổng tiền hàng:</Text>
          <Text style={styles.priceValue}>{formatPrice(totalAmount)}</Text>
        </View>

        <View style={styles.priceRow}>
          <Text style={styles.priceLabel}>Phí vận chuyển:</Text>
          <Text style={styles.priceValue}>{formatPrice(shippingFee)}</Text>
        </View>

        <View style={[styles.priceRow, styles.finalPriceRow]}>
          <Text style={styles.finalPriceLabel}>Tổng cộng:</Text>
          <Text style={styles.finalPriceValue}>{formatPrice(finalAmount)}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.checkoutButton} onPress={handleCheckout}>
        <Text style={styles.checkoutButtonText}>Đặt Hàng</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backButtonText}>Quay lại giỏ hàng</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffffff",
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
    textAlign: "center",
  },
  section: {
    marginBottom: 25,
    backgroundColor: "#f8f9fa",
    padding: 15,
    borderRadius: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 15,
  },
  input: {
    backgroundColor: "white",
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 6,
    padding: 12,
    marginBottom: 10,
    fontSize: 16,
  },
  paymentOption: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    backgroundColor: "white",
    borderRadius: 6,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  paymentOptionSelected: {
    borderColor: "#007AFF",
    backgroundColor: "#e7f3ff",
  },
  radioContainer: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: "#ccc",
    marginRight: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  radio: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "transparent",
  },
  radioSelected: {
    backgroundColor: "#007AFF",
  },
  paymentText: {
    fontSize: 16,
    color: "#333",
  },
  priceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  finalPriceRow: {
    borderTopWidth: 1,
    borderTopColor: "#ddd",
    paddingTop: 12,
    marginTop: 8,
  },
  priceLabel: {
    fontSize: 16,
    color: "#666",
  },
  priceValue: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },
  finalPriceLabel: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
  },
  finalPriceValue: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#007AFF",
  },
  checkoutButton: {
    backgroundColor: "#28a745",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 15,
  },
  checkoutButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
  backButton: {
    backgroundColor: "#6c757d",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
  },
  backButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
});

export default CheckoutScreen;
