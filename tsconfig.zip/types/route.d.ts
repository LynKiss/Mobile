type RootStackParamList = {
  Home: undefined;
  Detail: { id: number; title: string; start: number }; // trong trường hợp để trống cũng được viết thêm |underfine
  About: undefined;
  Login: undefined;
  Register: undefined;
  HomeLayout: undefined;
  HomeNew: undefined;
  Cart: undefined;
  Checkout: undefined;
};

export { RootStackParamList };

declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}
declare module "*.png";
